#!/usr/bin/env python3
"""
============================================================
 FR3 - Camera Stream Launch File
============================================================

Launches the camera_publisher node with parameters loaded from
config/camera_params.yaml.

Usage:
    # With defaults from the YAML config:
    ros2 launch camera_stream camera_stream.launch.py

    # Override the camera URL at launch time:
    ros2 launch camera_stream camera_stream.launch.py \
        camera_url:=rtsp://admin:CODE@192.168.1.20:554/H.264

    # Also start the test subscriber (with display window):
    ros2 launch camera_stream camera_stream.launch.py start_test:=true
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory("camera_stream")
    default_params = os.path.join(pkg_share, "config", "camera_params.yaml")

    # --------------------------------------------------------
    # Launch arguments (overridable from the command line)
    # --------------------------------------------------------
    params_file_arg = DeclareLaunchArgument(
        "params_file",
        default_value=default_params,
        description="Path to the camera parameters YAML file."
    )
    camera_url_arg = DeclareLaunchArgument(
        "camera_url",
        default_value="",
        description="Override the camera RTSP/HTTP URL."
    )
    start_test_arg = DeclareLaunchArgument(
        "start_test",
        default_value="false",
        description="Also start the test_subscriber node."
    )

    params_file = LaunchConfiguration("params_file")
    camera_url  = LaunchConfiguration("camera_url")
    start_test  = LaunchConfiguration("start_test")

    # --------------------------------------------------------
    # camera_publisher node
    # --------------------------------------------------------
    camera_node = Node(
        package="camera_stream",
        executable="camera_publisher",
        name="camera_publisher",
        output="screen",
        parameters=[
            params_file,
            # camera_url, if provided, overrides the YAML value
            {"camera_url": camera_url} if camera_url else {},
        ],
    )

    # --------------------------------------------------------
    # Optional test_subscriber node
    # --------------------------------------------------------
    test_node = Node(
        package="camera_stream",
        executable="test_subscriber",
        name="test_subscriber",
        output="screen",
        condition=IfCondition(start_test),
        parameters=[{"show_window": False}],
    )

    return LaunchDescription([
        params_file_arg,
        camera_url_arg,
        start_test_arg,
        camera_node,
        test_node,
    ])
