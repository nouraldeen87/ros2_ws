#!/usr/bin/env python3
"""
============================================================
 FR3 - Receive Video Input from Cameras
 Smart Real-Time Employee Activity and Emotion Monitoring System
============================================================

Functional Requirement:
    FR3: The system shall receive real-time video input from
         connected cameras for monitoring and analysis.

Node:  camera_publisher
Role:  Edge device (Raspberry Pi) node that connects to an IP camera
       (EZVIZ BC1 via RTSP), captures live frames with OpenCV, and
       publishes them as sensor_msgs/Image on a ROS 2 topic for the
       downstream AI modules (FR1 emotion, FR2 activity, dashboard).

Architecture:
    IP Camera (RTSP) → Raspberry Pi → camera_publisher node
                       → /camera/video_stream (sensor_msgs/Image)
                       → AI processing modules

Highlights:
    - Configurable parameters (URL, width, height, fps, topic, etc.)
    - Automatic reconnection with exponential backoff
    - Per-frame exception handling so one bad frame never kills the node
    - Structured logging via the ROS 2 logger
    - Optimized for Raspberry Pi (resize on capture, FFMPEG/TCP transport)
"""

import time

import cv2
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy

from sensor_msgs.msg import Image
from cv_bridge import CvBridge


class CameraPublisher(Node):
    """ROS 2 node that streams an IP camera onto an Image topic."""

    def __init__(self):
        super().__init__("camera_publisher")

        # --------------------------------------------------------
        # 1. Declare configurable parameters (override via launch /
        #    CLI / YAML). Defaults match the EZVIZ BC1 + Raspberry Pi.
        # --------------------------------------------------------
        self.declare_parameter("camera_url",  "rtsp://admin:XBUDLD@192.168.1.10:554/H.264")
        self.declare_parameter("topic_name",  "/camera/video_stream")
        self.declare_parameter("frame_width",  640)
        self.declare_parameter("frame_height", 480)
        self.declare_parameter("fps",          15.0)
        self.declare_parameter("reconnect_delay_sec",     2.0)
        self.declare_parameter("max_reconnect_delay_sec", 30.0)
        self.declare_parameter("use_tcp_transport",       True)
        self.declare_parameter("camera_frame_id",         "camera_link")

        # Read the parameter values
        self.camera_url   = self.get_parameter("camera_url").value
        self.topic_name   = self.get_parameter("topic_name").value
        self.frame_width  = int(self.get_parameter("frame_width").value)
        self.frame_height = int(self.get_parameter("frame_height").value)
        self.fps          = float(self.get_parameter("fps").value)
        self.reconnect_delay     = float(self.get_parameter("reconnect_delay_sec").value)
        self.max_reconnect_delay = float(self.get_parameter("max_reconnect_delay_sec").value)
        self.use_tcp     = bool(self.get_parameter("use_tcp_transport").value)
        self.frame_id    = self.get_parameter("camera_frame_id").value

        # --------------------------------------------------------
        # 2. QoS profile tuned for a video stream.
        #    BEST_EFFORT + small queue = low latency (drop old frames
        #    rather than buffer them, which is what you want for live
        #    video on a constrained device like the Pi).
        # --------------------------------------------------------
        qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=1,
        )

        # --------------------------------------------------------
        # 3. Publisher + cv_bridge (converts OpenCV ↔ ROS Image)
        # --------------------------------------------------------
        self.publisher = self.create_publisher(Image, self.topic_name, qos)
        self.bridge    = CvBridge()

        # Capture handle (created lazily, recreated on reconnect)
        self.cap = None
        self._current_reconnect_delay = self.reconnect_delay
        self._frame_count = 0

        # --------------------------------------------------------
        # 4. Open the camera, then start the periodic capture timer.
        # --------------------------------------------------------
        self._open_camera()

        timer_period = 1.0 / self.fps if self.fps > 0 else 0.066  # seconds
        self.timer = self.create_timer(timer_period, self._capture_and_publish)

        self.get_logger().info(
            f"camera_publisher started | url={self._safe_url()} "
            f"| topic={self.topic_name} | {self.frame_width}x{self.frame_height} "
            f"@ {self.fps} fps"
        )

    # ============================================================
    # Camera open / reopen
    # ============================================================
    def _open_camera(self) -> bool:
        """
        (Re)open the camera stream. Returns True on success.

        On the Raspberry Pi the FFMPEG backend with TCP transport is the
        most reliable for RTSP IP cameras like the EZVIZ BC1.
        """
        # Force TCP transport for RTSP (more reliable than UDP over WiFi)
        if self.use_tcp and self.camera_url.lower().startswith("rtsp"):
            import os
            os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;tcp"

        # Release any previous handle
        if self.cap is not None:
            self.cap.release()
            self.cap = None

        try:
            # CAP_FFMPEG is the recommended backend for network streams
            self.cap = cv2.VideoCapture(self.camera_url, cv2.CAP_FFMPEG)

            # Keep the internal buffer tiny → lower latency
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

            if not self.cap.isOpened():
                self.get_logger().warn(
                    f"Could not open camera stream: {self._safe_url()}"
                )
                return False

            self.get_logger().info("Camera stream opened successfully.")
            # Reset the backoff on a successful connect
            self._current_reconnect_delay = self.reconnect_delay
            return True

        except Exception as e:
            self.get_logger().error(f"Exception while opening camera: {e}")
            return False

    # ============================================================
    # Capture + publish (called by the timer)
    # ============================================================
    def _capture_and_publish(self):
        """Grab one frame, convert it, and publish it."""
        # If we don't have a working capture, try to reconnect.
        if self.cap is None or not self.cap.isOpened():
            self._handle_reconnect()
            return

        try:
            ret, frame = self.cap.read()
        except Exception as e:
            self.get_logger().error(f"Exception during frame read: {e}")
            ret, frame = False, None

        if not ret or frame is None:
            # Stream hiccup or disconnect — trigger reconnect logic
            self.get_logger().warn("Frame read failed; attempting reconnect.")
            self._handle_reconnect()
            return

        try:
            # Resize on the edge device to cut bandwidth + downstream load
            if (frame.shape[1] != self.frame_width or
                    frame.shape[0] != self.frame_height):
                frame = cv2.resize(frame, (self.frame_width, self.frame_height))

            # Convert OpenCV BGR image → ROS 2 sensor_msgs/Image
            msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = self.frame_id

            self.publisher.publish(msg)

            self._frame_count += 1
            # Log a heartbeat every ~5 seconds worth of frames
            if self._frame_count % max(1, int(self.fps * 5)) == 0:
                self.get_logger().info(
                    f"Published {self._frame_count} frames "
                    f"(latest {self.frame_width}x{self.frame_height})"
                )

        except Exception as e:
            # A single bad frame must NOT kill the node
            self.get_logger().error(f"Failed to publish frame: {e}")

    # ============================================================
    # Reconnection with exponential backoff
    # ============================================================
    def _handle_reconnect(self):
        """Attempt to reopen the stream, backing off on repeated failure."""
        self.get_logger().warn(
            f"Reconnecting in {self._current_reconnect_delay:.1f}s ..."
        )
        time.sleep(self._current_reconnect_delay)

        if self._open_camera():
            self.get_logger().info("Reconnected to camera stream.")
        else:
            # Exponential backoff, capped at max_reconnect_delay
            self._current_reconnect_delay = min(
                self._current_reconnect_delay * 2,
                self.max_reconnect_delay
            )

    # ============================================================
    # Helpers
    # ============================================================
    def _safe_url(self) -> str:
        """Mask credentials in the URL before logging it."""
        url = self.camera_url
        if "@" in url and "://" in url:
            scheme, rest = url.split("://", 1)
            if "@" in rest:
                creds, host = rest.split("@", 1)
                return f"{scheme}://****:****@{host}"
        return url

    def destroy_node(self):
        """Clean shutdown — release the camera handle."""
        if self.cap is not None:
            self.cap.release()
        super().destroy_node()


# ============================================================
# Entry point
# ============================================================
def main(args=None):
    rclpy.init(args=args)
    node = CameraPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down camera_publisher (Ctrl+C).")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
