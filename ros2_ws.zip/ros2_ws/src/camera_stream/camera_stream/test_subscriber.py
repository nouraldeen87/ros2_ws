#!/usr/bin/env python3
"""
============================================================
 FR3 - Test Subscriber (verification node)
============================================================

A simple ROS 2 subscriber that confirms the camera_publisher is
working. It subscribes to the video topic, prints frame metadata,
and (optionally) shows the live feed in an OpenCV window.

Use this to verify FR3 end-to-end without any AI processing:

    ros2 run camera_stream test_subscriber

If you are running with a display (not headless), pass:

    ros2 run camera_stream test_subscriber --ros-args -p show_window:=true
"""

import cv2
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy

from sensor_msgs.msg import Image
from cv_bridge import CvBridge


class TestSubscriber(Node):
    """Subscribes to the camera topic and reports what it receives."""

    def __init__(self):
        super().__init__("test_subscriber")

        self.declare_parameter("topic_name",  "/camera/video_stream")
        self.declare_parameter("show_window", False)

        self.topic_name  = self.get_parameter("topic_name").value
        self.show_window = bool(self.get_parameter("show_window").value)

        # Must match the publisher's QoS (BEST_EFFORT) or no data arrives
        qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=1,
        )

        self.subscription = self.create_subscription(
            Image, self.topic_name, self._on_frame, qos
        )
        self.bridge = CvBridge()
        self._count = 0

        self.get_logger().info(
            f"test_subscriber listening on {self.topic_name} "
            f"(show_window={self.show_window})"
        )

    def _on_frame(self, msg: Image):
        self._count += 1
        # Print metadata for the first frame and then periodically
        if self._count == 1 or self._count % 30 == 0:
            self.get_logger().info(
                f"Frame #{self._count} | {msg.width}x{msg.height} "
                f"| encoding={msg.encoding} "
                f"| stamp={msg.header.stamp.sec}.{msg.header.stamp.nanosec}"
            )

        if self.show_window:
            try:
                frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
                cv2.imshow("FR3 Test Subscriber", frame)
                cv2.waitKey(1)
            except Exception as e:
                self.get_logger().error(f"Display error: {e}")


def main(args=None):
    rclpy.init(args=args)
    node = TestSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down test_subscriber.")
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
