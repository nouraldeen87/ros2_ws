#!/usr/bin/env python3
"""
============================================================
 FR3 → FR1 Bridge Node
============================================================

Connects the ROS 2 video stream (FR3) to the existing Flask-based
emotion/activity backend (FR1/FR6).

This node subscribes to /camera/video_stream, throttles the frame
rate (we don't need 15 fps for emotion detection), encodes each
sampled frame as JPEG, and POSTs it to the FR1/FR6 ingestion
endpoint.

This is the glue between the ROS 2 edge layer and the Python AI
backend, so the rest of the project (FR1, FR2, FR4, FR6, FR8) does
not need to know about ROS 2 at all.

    ros2 run camera_stream fr1_bridge \
        --ros-args -p backend_url:=http://192.168.1.50:5000/api/frame
"""

import cv2
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy

from sensor_msgs.msg import Image
from cv_bridge import CvBridge

import requests


class FR1Bridge(Node):
    """Forwards sampled camera frames to the FR1/FR6 backend over HTTP."""

    def __init__(self):
        super().__init__("fr1_bridge")

        self.declare_parameter("topic_name",       "/camera/video_stream")
        self.declare_parameter("backend_url",      "http://localhost:5000/api/frame")
        self.declare_parameter("source_name",      "ros2_camera_1")
        self.declare_parameter("send_every_n",     15)     # throttle
        self.declare_parameter("jpeg_quality",     80)
        self.declare_parameter("request_timeout",  2.0)

        self.topic_name  = self.get_parameter("topic_name").value
        self.backend_url = self.get_parameter("backend_url").value
        self.source_name = self.get_parameter("source_name").value
        self.send_every_n = int(self.get_parameter("send_every_n").value)
        self.jpeg_quality = int(self.get_parameter("jpeg_quality").value)
        self.timeout     = float(self.get_parameter("request_timeout").value)

        qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=1,
        )

        self.subscription = self.create_subscription(
            Image, self.topic_name, self._on_frame, qos
        )
        self.bridge = CvBridge()
        self._count = 0
        self._sent  = 0

        self.get_logger().info(
            f"fr1_bridge: {self.topic_name} → {self.backend_url} "
            f"(every {self.send_every_n} frames, source={self.source_name})"
        )

    def _on_frame(self, msg: Image):
        self._count += 1
        # Throttle: only forward every Nth frame
        if self._count % self.send_every_n != 0:
            return

        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")

            # Encode as JPEG for compact HTTP transfer
            ok, buf = cv2.imencode(
                ".jpg", frame,
                [int(cv2.IMWRITE_JPEG_QUALITY), self.jpeg_quality]
            )
            if not ok:
                self.get_logger().warn("JPEG encoding failed; skipping frame.")
                return

            files = {"frame": ("frame.jpg", buf.tobytes(), "image/jpeg")}
            data  = {"source": self.source_name}

            resp = requests.post(self.backend_url, files=files, data=data,
                                  timeout=self.timeout)
            if resp.status_code == 200:
                self._sent += 1
                if self._sent % 10 == 0:
                    self.get_logger().info(
                        f"Forwarded {self._sent} frames to backend.")
            else:
                self.get_logger().warn(
                    f"Backend returned HTTP {resp.status_code}")

        except requests.exceptions.RequestException as e:
            self.get_logger().warn(f"Backend unreachable: {e}")
        except Exception as e:
            self.get_logger().error(f"Bridge error: {e}")


def main(args=None):
    rclpy.init(args=args)
    node = FR1Bridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down fr1_bridge.")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
