# FR3 — Receive Video Input from Cameras (ROS 2)

> *"The system shall receive real-time video input from connected
> cameras for monitoring and analysis."*

ROS 2 package that runs on a **Raspberry Pi 4** edge device, connects to
an **EZVIZ BC1** IP camera over RTSP, and publishes live video frames to
a ROS 2 topic for the downstream AI modules (FR1 emotion, FR2 activity)
and the dashboard.

---

## Architecture

```
┌──────────────┐    RTSP     ┌──────────────────┐   sensor_msgs/Image
│  EZVIZ BC1   │ ──────────► │  Raspberry Pi 4  │ ─────────────────────►
│  IP Camera   │   (WiFi)    │  camera_publisher│   /camera/video_stream
│  (4MP, 2K)   │             │  (ROS 2 node)    │
└──────────────┘             └──────────────────┘
                                                         │
                          ┌──────────────────────────────┼───────────────┐
                          ▼                               ▼               ▼
                  ┌───────────────┐            ┌──────────────┐   ┌──────────────┐
                  │ test_subscriber│            │  fr1_bridge  │   │ rqt_image_view│
                  │ (verify feed) │            │ POST → FR1   │   │ (visual test)│
                  └───────────────┘            └──────┬───────┘   └──────────────┘
                                                       ▼
                                              ┌──────────────────┐
                                              │ FR1/FR6 backend  │
                                              │ (Flask + Mongo)  │
                                              └──────────────────┘
```

---

## Hardware

| Component | Model | Role |
|---|---|---|
| Edge device | Raspberry Pi 4 Model B | Runs ROS 2 + capture node |
| IP camera | EZVIZ BC1 (CS-BC1-B3, 4MP) | RTSP video source |
| Base station | EZVIZ BC1 hub | Bridges cameras to the network |

---

## Package Structure

```
ros2_ws/
└── src/
    └── camera_stream/
        ├── camera_stream/
        │   ├── __init__.py
        │   ├── camera_publisher.py     ← main FR3 node
        │   ├── test_subscriber.py      ← verification node
        │   └── fr1_bridge.py           ← forwards frames to FR1/FR6
        ├── config/
        │   └── camera_params.yaml      ← all camera parameters
        ├── launch/
        │   └── camera_stream.launch.py ← launch file
        ├── resource/
        │   └── camera_stream
        ├── package.xml
        ├── setup.py
        └── setup.cfg
```

---

## Nodes

| Node | Executable | Purpose |
|---|---|---|
| Camera Publisher | `camera_publisher` | Captures RTSP, publishes `sensor_msgs/Image` |
| Test Subscriber | `test_subscriber` | Confirms the feed works (prints metadata) |
| FR1 Bridge | `fr1_bridge` | Throttles + POSTs frames to the FR1/FR6 API |

---

## Prerequisites (on the Raspberry Pi)

### 1. Install ROS 2 Humble

Follow the official guide for Ubuntu 22.04 (64-bit) on Raspberry Pi:
https://docs.ros.org/en/humble/Installation/Ubuntu-Install-Debs.html

### 2. Install dependencies

```bash
sudo apt update
sudo apt install -y \
    ros-humble-cv-bridge \
    ros-humble-sensor-msgs \
    ros-humble-rqt-image-view \
    python3-opencv \
    python3-colcon-common-extensions

pip3 install requests
```

---

## Build (colcon)

```bash
# 1. Create the workspace (if you don't have it yet)
mkdir -p ~/ros2_ws/src

# 2. Copy the camera_stream package into ~/ros2_ws/src/

# 3. Source ROS 2
source /opt/ros/humble/setup.bash

# 4. Build
cd ~/ros2_ws
colcon build --packages-select camera_stream

# 5. Source the workspace overlay
source install/setup.bash
```

> Tip: add `source ~/ros2_ws/install/setup.bash` to your `~/.bashrc`
> so every new terminal has the package available.

---

## Configure

### Find your EZVIZ BC1 RTSP URL

EZVIZ BC1 RTSP format:
```
rtsp://<username>:<verification_code>@<camera_ip>:554/H.265
```

| Part | Where to find it |
|---|---|
| `username` | usually `admin` |
| `verification_code` | printed on the camera label (the EZVIZ "verification code") |
| `camera_ip` | check your router's DHCP client list, or the EZVIZ app |
| port | `554` (RTSP default) |

Edit `config/camera_params.yaml`:
```yaml
camera_publisher:
  ros__parameters:
    camera_url: "rtsp://admin:YOUR_CODE@192.168.1.10:554/H.265"
    frame_width:  640
    frame_height: 480
    fps:          15.0
```

> Rebuild after editing the YAML so the installed copy updates:
> `colcon build --packages-select camera_stream`

---

## Run

### Option A — Launch file (recommended)

```bash
ros2 launch camera_stream camera_stream.launch.py
```

Override the URL without editing the YAML:
```bash
ros2 launch camera_stream camera_stream.launch.py \
    camera_url:=rtsp://admin:CODE@192.168.1.20:554/H.264
```

### Option B — Run the node directly

```bash
ros2 run camera_stream camera_publisher \
    --ros-args -p camera_url:=rtsp://admin:CODE@192.168.1.10:554/H.264
```

---

## Test the Feed

### 1. List the topic

In a second terminal (remember to `source install/setup.bash`):

```bash
ros2 topic list
# you should see: /camera/video_stream

ros2 topic hz /camera/video_stream
# shows the publish rate (~15 Hz)

ros2 topic info /camera/video_stream
# shows type: sensor_msgs/msg/Image
```

### 2. Visualize with rqt_image_view

```bash
ros2 run rqt_image_view rqt_image_view
```
Select `/camera/video_stream` from the dropdown — you should see the
live camera feed.

### 3. Or use the built-in test subscriber

```bash
ros2 run camera_stream test_subscriber
# prints frame metadata as frames arrive

# With a display window (non-headless Pi):
ros2 run camera_stream test_subscriber --ros-args -p show_window:=true
```

---

## Connect to the AI Backend (FR1/FR6)

The `fr1_bridge` node forwards sampled frames to the Flask backend:

```bash
ros2 run camera_stream fr1_bridge \
    --ros-args \
    -p backend_url:=http://192.168.1.50:5000/api/frame \
    -p source_name:=ros2_camera_1 \
    -p send_every_n:=15
```

> This requires a `/api/frame` endpoint on the FR6 backend that accepts
> a multipart JPEG upload. (See the note below.)

---

## Error Handling

The publisher node handles these failure modes gracefully:

| Failure | Behavior |
|---|---|
| Camera unreachable at startup | Logs a warning, retries with backoff |
| Stream disconnects mid-run | Detects failed read, reconnects automatically |
| Repeated reconnect failures | Exponential backoff (2s → 4s → 8s … capped at 30s) |
| Corrupt / unreadable frame | Logs error, skips that frame, keeps running |
| Bad credentials in URL | URL is masked in logs (`****:****`) |
| Ctrl+C | Clean shutdown, releases the camera handle |

---

## Performance Notes (Raspberry Pi)

| Optimization | Why |
|---|---|
| Resize frames on the Pi | Cuts bandwidth + downstream CPU load |
| `CAP_PROP_BUFFERSIZE = 1` | Drops stale frames → lower latency |
| QoS `BEST_EFFORT`, depth 1 | Live video should drop, not buffer |
| TCP RTSP transport | More reliable than UDP over WiFi |
| FFMPEG backend | Best OpenCV backend for network streams |
| Frame throttling in bridge | FR1 doesn't need 15 fps — every Nth frame |

For a Raspberry Pi 4, **640×480 @ 15 fps** is a good balance. If you see
high CPU, drop to `frame_width: 480, frame_height: 360, fps: 10`.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Could not open camera stream` | Check the URL, ping the camera IP, verify the verification code |
| Topic exists but `rqt_image_view` is blank | QoS mismatch — viewer must allow BEST_EFFORT |
| High latency | Lower resolution/fps, ensure TCP transport, check WiFi signal |
| `cv_bridge` import error | `sudo apt install ros-humble-cv-bridge` |
| Choppy stream | EZVIZ BC1 is battery-powered; ensure it's not in power-save sleep |
| No frames over WiFi | EZVIZ BC1 connects to its base station — confirm RTSP is enabled in the EZVIZ app settings |

---

## GP1 Documentation Notes

For Chapter 4 (Implementation):

> *"FR3 is implemented as a ROS 2 (Humble) package running on a
> Raspberry Pi 4 edge device. The `camera_publisher` node connects to an
> EZVIZ BC1 IP camera via RTSP using OpenCV's FFMPEG backend with TCP
> transport, captures frames continuously, resizes them on-device to
> reduce bandwidth, and publishes them as `sensor_msgs/Image` on the
> `/camera/video_stream` topic using a BEST_EFFORT QoS profile suited to
> low-latency live video. The node implements automatic reconnection
> with exponential backoff and per-frame exception handling to ensure
> resilience (NFR4 — Reliability). A bridge node decouples the ROS 2
> edge layer from the Python AI backend by forwarding sampled frames
> over HTTP, allowing the existing FR1/FR2/FR4/FR6/FR8 modules to remain
> unaware of ROS 2."*

### Why ROS 2 for FR3

| Reason | Benefit |
|---|---|
| Standard robotics middleware | Industry-standard for sensor data pipelines |
| Topic-based pub/sub | Multiple consumers (AI, dashboard, recording) from one stream |
| QoS policies | Fine-grained control over latency vs. reliability |
| Distributed by design | Camera node on Pi, AI nodes on a server — same API |
| `rqt` tooling | Built-in visualization + debugging |
