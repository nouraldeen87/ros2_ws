from setuptools import setup
import os
from glob import glob

package_name = "camera_stream"

setup(
    name=package_name,
    version="1.0.0",
    packages=[package_name],
    data_files=[
        # ament resource index marker
        ("share/ament_index/resource_index/packages",
            ["resource/" + package_name]),
        # package.xml
        ("share/" + package_name, ["package.xml"]),
        # launch files
        (os.path.join("share", package_name, "launch"),
            glob("launch/*.launch.py")),
        # config files
        (os.path.join("share", package_name, "config"),
            glob("config/*.yaml")),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="Zeid Salloum",
    maintainer_email="zeid@example.com",
    description="FR3 - Receive Video Input from Cameras (IP camera → ROS 2).",
    license="MIT",
    tests_require=["pytest"],
    entry_points={
        "console_scripts": [
            # ros2 run camera_stream camera_publisher
            "camera_publisher = camera_stream.camera_publisher:main",
            # ros2 run camera_stream test_subscriber
            "test_subscriber  = camera_stream.test_subscriber:main",
            # ros2 run camera_stream fr1_bridge
            "fr1_bridge       = camera_stream.fr1_bridge:main",
        ],
    },
)
